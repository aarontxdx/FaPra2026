#include "PreProcessingUnit.hpp"

#include "MemoryUsageHelper.hpp"

#include <boost/geometry.hpp>
#include <boost/geometry/algorithms/point_on_surface.hpp>
#include <chrono>

namespace
{
    namespace bg = boost::geometry;

    using BoostPoint = bg::model::point<double, 2, bg::cs::cartesian>;

    /**
     * This function finds a point on a polygon
     *
     * @param poly the polygon to test
     *
     * @return Point on the given polygon
     *
     * TODO: Maybe I have to do a point in polygon test before setting a new centroid
     */
    Point representativePoint(const std::vector<Point> &poly)
    {
        namespace bg = boost::geometry;

        bg::model::polygon<BoostPoint> polygon;

        for (const auto &p : poly)
            bg::append(polygon.outer(), BoostPoint(p.x, p.y));

        bg::correct(polygon);

        BoostPoint result;
        bg::point_on_surface(polygon, result);

        return {result.get<0>(), result.get<1>()};
    }

    /**
     * Die Funktion erstellt aus den Straßen einen Graphen, indem sie Straßen über
     * gemeinsame Endpunkte verbindet und daraus Adjazenzlisten sowie Knotengrade berechnet.
     *
     * This creates a graph from the given road group which is done by connecting end points.
     * It calculates a the node degree and adjacence lists
     */
    void buildGraph(const std::vector<Road> &group,
                    std::vector<std::vector<int>> &adj,
                    std::vector<int> &degree)
    {
        int n = group.size();

        std::unordered_map<QPoint, std::vector<int>, QPointHash> endpointMap;

        for (int i = 0; i < n; i++)
        {
            const auto &r = group[i];
            endpointMap[toQ(r.nodes.front())].push_back(i);
            endpointMap[toQ(r.nodes.back())].push_back(i);
        }

        adj.assign(n, {});

        for (int i = 0; i < n; i++)
        {
            const auto &r = group[i];

            QPoint ends[2] = {
                toQ(r.nodes.front()),
                toQ(r.nodes.back())};

            for (auto &ep : ends)
            {
                for (int j : endpointMap[ep])
                {
                    if (i != j)
                        adj[i].push_back(j);
                }
            }

            std::sort(adj[i].begin(), adj[i].end());
            adj[i].erase(std::unique(adj[i].begin(), adj[i].end()), adj[i].end());
        }

        degree.resize(n);
        for (int i = 0; i < n; i++)
            degree[i] = adj[i].size();
    }

    /**
     * goes through the graph from a given startpoint and collects all
     * connected streets, which are not visited at the moment
     */
    std::vector<int> buildChain(int start,
                                const std::vector<std::vector<int>> &adj,
                                std::vector<bool> &visited)
    {
        std::vector<int> chain;

        int current = start;
        int prev = -1;

        while (true)
        {
            if (visited[current])
                break;

            visited[current] = true;
            chain.push_back(current);

            int next = -1;

            for (int nb : adj[current])
            {
                if (nb != prev)
                {
                    next = nb;
                    break;
                }
            }

            if (next == -1)
                break;

            prev = current;
            current = next;
        }

        return chain;
    }

    /**
     * connects multiple road segments according to their end nodes to a single connected road
     */
    std::vector<Point> mergeChainGeometry(const std::vector<int> &chain,
                                          const std::vector<Road> &group)
    {
        auto same = [](const Point &a, const Point &b)
        {
            return std::abs(a.x - b.x) < 1e-6 &&
                   std::abs(a.y - b.y) < 1e-6;
        };

        std::vector<Point> line;

        for (int idx : chain)
        {
            const auto &r = group[idx];

            if (line.empty())
            {
                line = r.nodes;
                continue;
            }

            if (same(line.back(), r.nodes.front()))
            {
                line.insert(line.end(), r.nodes.begin() + 1, r.nodes.end());
            }
            else if (same(line.back(), r.nodes.back()))
            {
                auto tmp = r.nodes;
                std::reverse(tmp.begin(), tmp.end());
                line.insert(line.end(), tmp.begin() + 1, tmp.end());
            }
            else if (same(line.front(), r.nodes.back()))
            {
                line.insert(line.begin(), r.nodes.begin(), r.nodes.end() - 1);
            }
            else if (same(line.front(), r.nodes.front()))
            {
                auto tmp = r.nodes;
                std::reverse(tmp.begin(), tmp.end());
                line.insert(line.begin(), tmp.begin(), tmp.end() - 1);
            }
        }

        return line;
    }

    /**
     * build and merge chains for the preprocessing of roads
     */
    void mergeChains(const std::vector<Road> &group,
                     const std::vector<std::vector<int>> &adj,
                     const std::vector<int> &degree,
                     const std::string &name,
                     RoadType type,
                     std::vector<Road> &result)
    {
        int n = group.size();
        std::vector<bool> visited(n, false);

        for (int i = 0; i < n; i++)
        {
            if (visited[i])
                continue;

            // build chains
            std::vector<int> chain = buildChain(i, adj, visited);

            // merge their geometry
            std::vector<Point> line = mergeChainGeometry(chain, group);

            if (line.empty())
                continue;

            // build the new roads
            Road merged;
            merged.name = name;
            merged.type = type;
            merged.id = group[i].id;
            merged.nodes = std::move(line);

            result.push_back(std::move(merged));
        }
    }

    /**
     * merge candidate roads together and safe them in a result vector
     *
     * @param group list of Roads that should be merged
     * @param name the name of the road that is tested
     * @param type the type of the road that is tested
     * @param result the list of resulting roads
     */
    void processGroup(std::vector<Road> &group,
                      const std::string &name,
                      RoadType type,
                      std::vector<Road> &result)
    {
        if (group.empty())
            return;

        std::vector<std::vector<int>> adj;
        std::vector<int> degree;

        buildGraph(group, adj, degree);
        mergeChains(group, adj, degree, name, type, result);
    }
}

void PreProcessingUnit::preprocessBuildings(std::vector<Building> &buildings)
{
    helper::printMemoryUsageBuildings(buildings, "Memory of Buildings before Preprocessing:");

    auto startTime = std::chrono::steady_clock::now();

    for (auto &building : buildings)
    {
        building.centroid = representativePoint(building.polygon);
        building.polygon.clear();
        building.polygon.shrink_to_fit();
    }

    auto endTime = std::chrono::steady_clock::now();
    auto applyDuration =
        std::chrono::duration_cast<std::chrono::seconds>(endTime - startTime);
    std::cout << "\nTotal process Time Buildings: " << applyDuration.count() << " s\n";

    helper::printMemoryUsageBuildings(buildings, "Memory of Buildings after Preprocessing:");
}

void PreProcessingUnit::preprocessRoads(std::vector<Road> &roads)
{
    helper::printMemoryUsageRoads(roads, "Memory of Roads before Preprocessing:");

    auto startTime = std::chrono::steady_clock::now();

    // 1. split roads into named and unnamed groups
    std::unordered_map<Key, std::vector<Road>, KeyHash> namedGroups;
    std::unordered_map<RoadType, std::vector<Road>> unnamedGroups;

    for (auto &r : roads)
    {
        if (!r.name.empty() && r.name != "unknown")
        {
            Key k{r.name, r.type, true};
            namedGroups[k].push_back(std::move(r));
        }
        else
        {
            unnamedGroups[r.type].push_back(std::move(r));
        }
    }

    std::vector<Road> result;

    // 2. process each of the two groups
    for (auto &[key, group] : namedGroups)
    {
        processGroup(group, key.name, key.type, result);
    }

    for (auto &[type, group] : unnamedGroups)
    {
        processGroup(group, "", type, result);
    }

    roads = std::move(result);

    auto endTime = std::chrono::steady_clock::now();
    auto applyDuration =
        std::chrono::duration_cast<std::chrono::seconds>(endTime - startTime);

    std::cout << "\nTotal process Time Roads: " << applyDuration.count() << " s\n";

    helper::printMemoryUsageRoads(roads, "Memory of Roads after Preprocessing:");
}